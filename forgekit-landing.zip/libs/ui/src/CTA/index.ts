export { CTA, type CTAProps } from './CTA'
