export { GradientText, type GradientTextProps } from './GradientText'
