export { Hero, type HeroProps } from './Hero'
