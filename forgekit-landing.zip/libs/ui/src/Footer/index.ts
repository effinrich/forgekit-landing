export { Footer, type FooterProps, type FooterColumn, type FooterLink } from './Footer'
